from django.shortcuts import render
from django.http import HttpResponse
from students.models import Student, Address

# Create your views here.
def welcome(request):
    # return HttpResponse("Welcome to Django Page")
    return render(request, "website/welcome.html", {"message": "Raj Joesph",
                                                    "number_of_students":Student.objects.count(),
                                                    "students":Student.objects.all()})