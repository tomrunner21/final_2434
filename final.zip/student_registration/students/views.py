from django.shortcuts import render

from .models import Student
# Create your views here.
def detail(request, id):
    student = Student.objects.get(pk=id)
    return render(request, "students/detail.html", {"student":student})