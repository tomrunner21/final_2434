from django.db import models

# Create your models here.
class Address(models.Model):
    name = models.CharField(max_length=100)
    housenumber = models.IntegerField(default=1)
    street = models.CharField(max_length=100)
    zip = models.CharField(max_length=10)
    state = models.CharField(max_length=50)
    country = models.CharField(max_length=100)

class Student(models.Model):
    fname = models.CharField(max_length=100)
    lname = models.CharField(max_length=100)
    address = models.ForeignKey(Address, on_delete=models.CASCADE)
